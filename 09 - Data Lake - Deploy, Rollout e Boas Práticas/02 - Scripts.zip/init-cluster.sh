init-cluster.sh 

#!/bin/bash
echo ""
echo "INICIALIZANDO O HADOOP"
echo ""
$HADOOP_HOME/sbin/start-dfs.sh
echo ""
echo "INICIALIZANDO O YARN"
echo ""
$HADOOP_HOME/sbin/start-yarn.sh
echo ""
echo "INICIALIZANDO O HISTÓRICO DO SPARK"
echo ""
$SPARK_HOME/sbin/start-history-server.sh
echo ""
echo "===FIM==="
echo ""

>> stop-cluster.sh

#!/bin/bash
echo ""
echo "PARANDO O HADOOP"
echo ""
$HADOOP_HOME/sbin/stop-dfs.sh
echo ""
echo "PARANDO O YARN"
echo ""
$HADOOP_HOME/sbin/stop-yarn.sh
echo ""
echo "PARANDO O HISTÓRICO DO SPARK"
echo ""
$SPARK_HOME/sbin/stop-history-server.sh
echo ""
echo "===FIM==="
echo ""
